<?php

// Edit the lines below to add your Flickr API Key and Secret
// You can get these from http://www.flickr.com/services/apps/create/apply/

$flickrApiKey = 'PUT_YOUR_FLICKR_API_KEY_HERE';
$flickrApiSecret = 'PUT_YOUR_FLICKR_API_SECRET_HERE';

