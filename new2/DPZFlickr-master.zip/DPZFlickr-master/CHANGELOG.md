Version 1.3 - 1st June 2014
=================================

Update all Flickr API URLs to use https

Version 1.2.3 - 13th January 2013
=================================

Fix documentation to list correct PHP version needed
Update composer.json

Version 1.2.2 - 16th September 2012
===================================

Fix broken version number

Version 1.2.1 - 16th September 2012
===================================

Minor documentation updates

Version 1.2 - 16th September 2012
=================================

Add support for photo upload and replace.

Version 1.1 - 16th September 2012
=================================

Restructure code to place in DPZ namespace.


Version 1.0 - 4th August 2012
=============================

Initial version.

