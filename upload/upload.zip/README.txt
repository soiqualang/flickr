VIETNAMESE

1. Đổi tên file "includes/config-en.php" hoặc "includes/config-vi.php" thành "includes/config.php"
2. Cấu hình tài khoản, API ở trong file config.php này, ở mỗi chỗ cấu hình vui lòng đọc comment
3. Khi cấu hình xong, ở đầu dòng nếu có // thì xóa đi vì đó là ký tự comment, xóa đi thì dòng code đó mới có tác dụng


ENGLISH

1. Rename file "includes/config-en.php" or "includes/config-vi.php" to "includes/config.php"
2. Config accounts, APIs in the "config.php" file, for each setting have some comments for it, please read it
3. After done, remove // in first line if have
