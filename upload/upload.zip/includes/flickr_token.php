<?php
return array (
  'soiqualang' => 
  array (
    'token' => '72157669196987987-d2bcdf04f8a63022',
    'secret' => 'c81399c369238bba',
  ),
);